package dutta.biswajyoti.jersey.first;

import java.util.Collection;
import java.util.HashMap;
import java.util.Map;

import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

@Path("/books")
public class BookService {

	private static Map<Long, Book> books;
	
	static {
		books = new HashMap<Long, Book>();
		Book book1 = new Book(1, "Book Title", "Some Author", "Something about the book 1. What it is about, the genre etc.", 
        		"10.50 EUR", "ISBN 123-4567890");
		Book book2 = new Book(2, "Book Title 2", "Some Author 2", "Something about the book 2. What it is about, the genre etc.", 
        		"11.50 EUR", "ISBN 908-7654321");
		books.put(book1.getId(), book1);
		books.put(book2.getId(), book2);

	}
	
	@GET
	@Produces(MediaType.TEXT_PLAIN) 
	public String getBookClassPurpose(){
		return "Service for books.";
	}
	
	@GET  
    @Path("/name/{id}")  
    @Produces(MediaType.TEXT_PLAIN)  
    public String getBookNameFromID(@PathParam("id") String id){ 
	    String returnValue = "Book with this id does not exist.";
        try  {
        	Long bookId = Long.parseLong(id);
        	if (books.containsKey(bookId)) {
        		returnValue = books.get(bookId).getName();
        	}      
        } catch (NumberFormatException nfe) {
    	    returnValue = "Invalid book id. Please use a numerical value.";
        }
        return returnValue;
    }  
	
	@GET  
    @Path("/details/{id}")
	@Produces(MediaType.APPLICATION_XML)
    public Book getXMLBookDetailsFromID(@PathParam("id") String id){  
		Book book = null;
		try {
			book = books.get(Long.parseLong(id));	
		} catch (NumberFormatException nfe) {}
		return book;
    }
	
	@GET  
    @Path("/details/all")  
    @Produces(MediaType.APPLICATION_XML)  
    public Collection<Book> getBooks(){  
		return books.values();
	}
	
//	@GET
//	@Path("/json/details/{id}")
//	@Produces(MediaType.APPLICATION_JSON)
//	public Book getJSONBookDetailsFromID(@PathParam("id") String id) {
//		System.out.println("Method identified");
//		Book book = null;
//		try {
//			book = books.get(Long.parseLong(id));	
//		} catch (NumberFormatException nfe) {}
//		return book;
//	}
	
	@Path("/modify")
	@PUT
	@Consumes(MediaType.APPLICATION_XML)
	public Response modifyBook(Book book){
		books.put(book.getId(), book);
		return Response.status(200).entity(book.toString()).build();
	}
	
	@Path("/create")
	@POST
	@Consumes(MediaType.APPLICATION_XML)
	public Response createBook(Book book){
		books.put(book.getId(), book);
		return Response.status(200).entity(book.toString()).build();
	}
	
	@Path("/delete/{id}")
	@DELETE
	@Consumes(MediaType.APPLICATION_XML)
	public void deleteBook(@PathParam("id") Long id){
		System.out.println("to be deleted: " + id);
		 books.remove(id);
	}
	
}
